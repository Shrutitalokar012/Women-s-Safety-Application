package com.example.women_safety;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Activity_display_relatives extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RelativeAdapter adapter;
    private List<Relative> relativeList;
    private DatabaseReference relativesRef;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_relatives);

        // Setup RecyclerView
        recyclerView = findViewById(R.id.recyclerViewRelatives);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        relativeList = new ArrayList<>();
        adapter = new RelativeAdapter(relativeList);
        recyclerView.setAdapter(adapter);

        // Retrieve the logged in user's ID from SharedPreferences
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String userId = sharedPreferences.getString("uid", "");
        if (userId.isEmpty()) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Get Firebase Database Reference for relatives of the current user
        relativesRef = FirebaseDatabase.getInstance().getReference("Users").child(userId).child("relatives");

        // Fetch relatives from Firebase and listen for changes
        fetchRelatives();

        // Back button to close this activity
        ImageButton backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(v -> finish());
    }

    private void fetchRelatives() {
        relativesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                relativeList.clear();
                for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                    Relative relative = childSnapshot.getValue(Relative.class);
                    if (relative != null) {
                        relativeList.add(relative);
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Activity_display_relatives.this, "Error fetching relatives: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Model class representing a Relative
    public static class Relative {
        public String relativeId;
        public String name;
        public String phone;
        public String relationship;

        // Default constructor required for Firebase deserialization
        public Relative() {}

        public Relative(String relativeId, String name, String phone, String relationship) {
            this.relativeId = relativeId;
            this.name = name;
            this.phone = phone;
            this.relationship = relationship;
        }
    }

    // RecyclerView Adapter for displaying relatives
    private class RelativeAdapter extends RecyclerView.Adapter<RelativeAdapter.RelativeViewHolder> {
        private List<Relative> relatives;

        public RelativeAdapter(List<Relative> relatives) {
            this.relatives = relatives;
        }

        @NonNull
        @Override
        public RelativeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_relative1, parent, false);
            return new RelativeViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull RelativeViewHolder holder, int position) {
            Relative relative = relatives.get(position);
            holder.tvName.setText(relative.name);
            holder.tvRelationship.setText(relative.relationship);
            holder.tvPhone.setText(relative.phone);

            // Call button launches the dialer with the relative's phone number
            holder.btnCall.setOnClickListener(v -> {
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:" + relative.phone));
                startActivity(callIntent);
            });

            // Delete button removes the relative from the database
            holder.btnDelete.setOnClickListener(v -> {
                relativesRef.child(relative.relativeId).removeValue()
                        .addOnSuccessListener(aVoid -> Toast.makeText(Activity_display_relatives.this, "Relative deleted successfully", Toast.LENGTH_SHORT).show())
                        .addOnFailureListener(e -> Toast.makeText(Activity_display_relatives.this, "Failed to delete relative: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            });

            // Item click listener to open the update activity.
            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(Activity_display_relatives.this, Activity_update_relative.class);
                intent.putExtra("relativeId", relative.relativeId);
                intent.putExtra("name", relative.name);
                intent.putExtra("phone", relative.phone);
                intent.putExtra("relationship", relative.relationship);
                startActivity(intent);
            });
        }


        @Override
        public int getItemCount() {
            return relatives.size();
        }

        class RelativeViewHolder extends RecyclerView.ViewHolder {
            TextView tvName, tvRelationship, tvPhone;
            ImageButton btnCall, btnDelete;

            public RelativeViewHolder(@NonNull View itemView) {
                super(itemView);
                tvName = itemView.findViewById(R.id.tv_relative_name);
                tvRelationship = itemView.findViewById(R.id.tv_relative_relationship);
                tvPhone = itemView.findViewById(R.id.tv_relative_phone);
                btnCall = itemView.findViewById(R.id.btn_call);
                btnDelete = itemView.findViewById(R.id.btn_delete);
            }
        }
    }
}
