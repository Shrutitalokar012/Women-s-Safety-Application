package com.example.women_safety;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.women_safety.Model.User;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Activty_verify_email extends AppCompatActivity {

    private TextInputEditText otpInput;
    private Button verifyEmail;
    private TextView resendOTP;

    // Registration details retrieved from the previous activity
    private String fullName, phone, emergencyContact, email, password, generatedOtp;

    // Firebase database reference
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activty_verify_email);

        otpInput = findViewById(R.id.otpInput);
        verifyEmail = findViewById(R.id.verifyEmail);
        resendOTP = findViewById(R.id.resendOTP);

        // Initialize Firebase Database reference (Users node)
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");

        // Retrieve registration details and generated OTP from intent extras
        Intent intent = getIntent();
        fullName = intent.getStringExtra("fullName");
        phone = intent.getStringExtra("phone");
        emergencyContact = intent.getStringExtra("emergencyContact");
        email = intent.getStringExtra("email");
        password = intent.getStringExtra("password");
        generatedOtp = intent.getStringExtra("generatedOtp");

        // Verify OTP when the button is clicked
        verifyEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String enteredOtp = otpInput.getText().toString().trim();
                if (TextUtils.isEmpty(enteredOtp)) {
                    Toast.makeText(Activty_verify_email.this, "Please enter OTP", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (enteredOtp.equals(generatedOtp)) {
                    // OTP matches: create a new user and store in Firebase
                    User user = new User(fullName, phone, emergencyContact, email, password);
                    String userId = databaseReference.push().getKey();
                    if (userId != null) {
                        databaseReference.child(userId).setValue(user, new DatabaseReference.CompletionListener() {
                            @Override
                            public void onComplete(DatabaseError error, @NonNull DatabaseReference ref) {
                                if (error == null) {
                                    // Registration successful: show a popup dialog
                                    new AlertDialog.Builder(Activty_verify_email.this)
                                            .setTitle("Registration Successful")
                                            .setMessage("User registered successfully!")
                                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {
                                                    dialog.dismiss();
                                                    // Optionally, navigate to the login or home screen
                                                    finish();
                                                }
                                            })
                                            .show();
                                } else {
                                    Toast.makeText(Activty_verify_email.this, "Registration failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                } else {
                    Toast.makeText(Activty_verify_email.this, "Incorrect OTP. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Resend OTP when the "Resend OTP?" text is clicked
        resendOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Generate a new 6-digit OTP
                generatedOtp = String.valueOf(100000 + new Random().nextInt(900000));
                sendOtpEmail(email, generatedOtp);
            }
        });
    }

    /**
     * Sends an OTP email to the given recipient using JavaMail in a background thread.
     *
     * @param recipientEmail The email address to send the OTP.
     * @param otp            The OTP to send.
     */
    private void sendOtpEmail(final String recipientEmail, final String otp) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String senderEmail = "womensafety06@gmail.com"; // Replace with your sender email
                    final String senderPassword = "hbkj rkcx kjae rlmi";      // Replace with your app-specific password

                    Properties props = new Properties();
                    props.put("mail.smtp.auth", "true");
                    props.put("mail.smtp.starttls.enable", "true");
                    props.put("mail.smtp.host", "smtp.gmail.com");
                    props.put("mail.smtp.port", "587");

                    Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(senderEmail, senderPassword);
                        }
                    });

                    Message message = new MimeMessage(session);
                    message.setFrom(new InternetAddress(senderEmail));
                    message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
                    message.setSubject("Your OTP Code");
                    message.setText("Your OTP is: " + otp);

                    Transport.send(message);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(Activty_verify_email.this, "OTP sent successfully", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (final Exception e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(Activty_verify_email.this, "Failed to send OTP: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }
}
