package com.example.women_safety;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.util.HashMap;
import java.util.Map;

public class Activity_profile extends AppCompatActivity {

    private TextInputEditText fullNameInput, emailInput, phoneInput, emergencyContactInput;
    private Button btnSave;
    private SharedPreferences sharedPreferences;
    // Variable to store the user's unique key once found
    private String userKey = null;
    private TextView userName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Initialize UI components
        fullNameInput = findViewById(R.id.fullNameInput);
        emailInput = findViewById(R.id.emailInput);
        phoneInput = findViewById(R.id.phoneInput);
        emergencyContactInput = findViewById(R.id.emergencyContactInput);
        btnSave = findViewById(R.id.btn_save);
        userName = findViewById(R.id.user_name);

        //back button
        ImageButton back = findViewById(R.id.back_button);
        back.setOnClickListener(v -> finish());

        //forgot password
        TextView forgotPassword = findViewById(R.id.forgotPasswordText);
        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Activity_profile.this, Activity_forgot_password.class);
                startActivity(intent);

            }
        });


        // Retrieve email from SharedPreferences
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String userEmail = sharedPreferences.getString("email", "");

        // Display the email (read-only)
        emailInput.setText(userEmail);

        // Reference the "Users" node
        DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("Users");

        // Query the database to find the user with the matching email
        Query query = usersRef.orderByChild("email").equalTo(userEmail);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Loop through the results (should be only one)
                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                        // Save the auto-generated key for later updates
                        userKey = userSnapshot.getKey();

                        // Retrieve and display the user profile details
                        String fullName = userSnapshot.child("fullName").getValue(String.class);
                        String phone = userSnapshot.child("phone").getValue(String.class);
                        String emergencyContact = userSnapshot.child("emergencyContact").getValue(String.class);

                        if (fullName != null)
                            userName.setText(fullName);
                            fullNameInput.setText(fullName);
                        if (phone != null)
                            phoneInput.setText(phone);
                        if (emergencyContact != null)
                            emergencyContactInput.setText(emergencyContact);
                    }
                } else {
                    Toast.makeText(Activity_profile.this, "User not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Activity_profile.this, "Failed to load profile", Toast.LENGTH_SHORT).show();
            }
        });

        // Set onClick listener for the Save button to update data
        btnSave.setOnClickListener(view -> {
            String updatedFullName = fullNameInput.getText().toString().trim();
            String updatedPhone = phoneInput.getText().toString().trim();
            String updatedEmergencyContact = emergencyContactInput.getText().toString().trim();

            // Create a map with the updated data
            Map<String, Object> updates = new HashMap<>();
            updates.put("fullName", updatedFullName);
            updates.put("phone", updatedPhone);
            updates.put("emergencyContact", updatedEmergencyContact);

            if (userKey != null) {
                // Update data using the user's unique key
                DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users").child(userKey);
                userRef.updateChildren(updates).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(Activity_profile.this, "Profile updated successfully", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Activity_profile.this, "Update failed. Please try again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            } else {
                Toast.makeText(Activity_profile.this, "User key not found. Cannot update profile.", Toast.LENGTH_SHORT).show();
            }
        });
    }


}
