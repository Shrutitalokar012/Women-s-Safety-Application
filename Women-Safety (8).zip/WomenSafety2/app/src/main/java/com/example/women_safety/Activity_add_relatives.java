package com.example.women_safety;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class Activity_add_relatives extends AppCompatActivity {

    private TextInputEditText inputName, inputPhone, inputRelationship;
    private Button btnSave;
    private DatabaseReference databaseReference;
    private SharedPreferences sharedPreferences;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_relatives);

        // Initialize UI components
        inputName = findViewById(R.id.input_name);
        inputPhone = findViewById(R.id.input_phone);
        inputRelationship = findViewById(R.id.input_relationship);
        btnSave = findViewById(R.id.btn_save);

        // Retrieve email from SharedPreferences
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String userId = sharedPreferences.getString("uid", "");


        // Initialize Firebase Database Reference
        databaseReference = FirebaseDatabase.getInstance().getReference("Users").child(userId).child("relatives");

        // Save button click listener
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addRelativeToDatabase();
            }
        });

        //back button
        ImageButton back = findViewById(R.id.back_button);
        back.setOnClickListener(v -> finish());
    }

    private void addRelativeToDatabase() {
        String name = inputName.getText().toString().trim();
        String phone = inputPhone.getText().toString().trim();
        String relationship = inputRelationship.getText().toString().trim();

        // Input validation
        if (TextUtils.isEmpty(name)) {
            inputName.setError("Enter full name");
            return;
        }
        if (TextUtils.isEmpty(phone)) {
            inputPhone.setError("Enter phone number");
            return;
        }
        if (TextUtils.isEmpty(relationship)) {
            inputRelationship.setError("Enter relationship");
            return;
        }

        // Generate a unique ID for the relative
        String relativeId = databaseReference.push().getKey();

        // Create a data structure
        Map<String, String> relativeData = new HashMap<>();
        relativeData.put("relativeId", relativeId);
        relativeData.put("name", name);
        relativeData.put("phone", phone);
        relativeData.put("relationship", relationship);

        // Store data in Firebase under "relatives"
        databaseReference.child(relativeId).setValue(relativeData)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(Activity_add_relatives.this, "Relative added successfully!", Toast.LENGTH_SHORT).show();
                    // Clear input fields
                    inputName.setText("");
                    inputPhone.setText("");
                    inputRelationship.setText("");
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(Activity_add_relatives.this, "Failed to add relative: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}
