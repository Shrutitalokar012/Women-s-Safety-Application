package com.example.women_safety;

public class OnboardingItem {
    private final int animationRes; // Lottie animation resource (R.raw.animation_file)
    private final String title;
    private final String description;

    public OnboardingItem(int animationRes, String title, String description) {
        this.animationRes = animationRes;
        this.title = title;
        this.description = description;
    }

    public int getAnimationRes() { // ✅ Updated method name
        return animationRes;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }
}
