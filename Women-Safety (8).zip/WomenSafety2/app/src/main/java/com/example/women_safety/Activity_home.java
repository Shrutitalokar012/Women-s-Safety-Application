package com.example.women_safety;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.telephony.SmsManager;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.switchmaterial.SwitchMaterial;

import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;
import java.util.List;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;



public class Activity_home extends AppCompatActivity {

    // Request code for permissions
    private static final int PERMISSION_REQUEST_CODE = 1;

    // UI components
    private LinearLayout card_Logout, card_Helpline, cardRelatives, cardSiren, cardSelf, howTo;
    public SwitchMaterial toggleShake;

    // Shared preferences for storing user data
    SharedPreferences preferences;

    // Media player for siren sound
    private MediaPlayer mediaPlayer;

    // Sensor-related fields for shake detection
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private SensorEventListener sensorEventListener;
    private Vibrator vibrator;
    private static final float SHAKE_THRESHOLD = 12.0f;      // Adjust as needed
    private static final int SHAKE_DURATION_THRESHOLD = 300;   // Minimum shake duration (ms)
    private long shakeStartTime = 0;
    private boolean isEmergencyTriggered = false;

    // Variables for handling volume button long press for emergency call
    private static final int LONG_PRESS_THRESHOLD = 1000;      // 1 second
    private long volumeDownPressTime = 0;

    // Fused location provider for accessing location
    private FusedLocationProviderClient fusedLocationProviderClient;

    // Variable to store parent's phone number (fetched from database's emergencyContact)
    private String parentPhoneNumber;
    // List to store all relative contact phone numbers
    private List<String> relativePhoneNumbers;

    private SpeechRecognizer speechRecognizer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Enable edge-to-edge layout
        setContentView(R.layout.activity_home);

        // Initialize UI elements and set click listeners
        initializeUI();

        // Initialize media player for siren sound
        mediaPlayer = MediaPlayer.create(this, R.raw.siren);

        // Initialize vibration service
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        // Setup sensor manager and accelerometer for shake detection
        initializeSensors();

        // Setup location provider
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        // Initialize shared preferences
        preferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        // Initialize relative phone numbers list
        relativePhoneNumbers = new ArrayList<>();

        // Fetch the parent's phone number from the database (emergencyContact)
        fetchEmergencyContacts();

        // Check and request necessary permissions
        checkPermissions();

        // Setup the toggle switch listener for emergency actions
        setupToggleListener();
        initializeVoiceRecognition();
    }

    /**
     * Fetches the emergency contact (parent's phone number) and relative contacts from Firebase using the email stored in SharedPreferences.
     */
    private void fetchEmergencyContacts() {
        String userId = preferences.getString("uid", null);
        if (userId != null) {
            // Fetch primary emergency contact
            DatabaseReference usersRef = FirebaseDatabase.getInstance().getReference("Users").child(userId);
            usersRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (snapshot.exists()) {
                        parentPhoneNumber = snapshot.child("emergencyContact").getValue(String.class);
                        if (parentPhoneNumber == null || parentPhoneNumber.isEmpty()) {
                            Toast.makeText(Activity_home.this, "Primary emergency contact not found!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(Activity_home.this, "User not found in database!", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(Activity_home.this, "Failed to fetch emergency contact: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

            // Fetch relative contacts
            DatabaseReference relativesRef = FirebaseDatabase.getInstance().getReference("Users").child(userId).child("relatives");
            relativesRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    relativePhoneNumbers.clear();
                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                        String phone = childSnapshot.child("phone").getValue(String.class);
                        if (phone != null && !phone.isEmpty()) {
                            relativePhoneNumbers.add(phone);
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(Activity_home.this, "Failed to fetch relative contacts: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Toast.makeText(this, "User ID not found in preferences!", Toast.LENGTH_SHORT).show();
        }
    }


    /**
     * Initialize and assign UI components along with their event listeners.
     */
    private void initializeUI() {
        // Retrieve views from the layout
        card_Helpline = findViewById(R.id.card_helpline);
        cardRelatives = findViewById(R.id.card_parent);
        card_Logout = findViewById(R.id.card_logout);
        cardSiren = findViewById(R.id.card_siren);
        cardSelf = findViewById(R.id.card_self);
        howTo = findViewById(R.id.card_howto);
        toggleShake = findViewById(R.id.toggle_shake);

        // Set onClick for helpline card: Navigate to emergency activity
        card_Helpline.setOnClickListener(view -> {
            Intent intent = new Intent(Activity_home.this, Activity_emergency.class);
            startActivity(intent);
        });

        // Set onClick for relatives card: Navigate to relatives activity
        cardRelatives.setOnClickListener(view -> {
            Intent intent = new Intent(Activity_home.this, Activity_relatives.class);
            startActivity(intent);
        });

        // Set onClick for logout: Log out user and navigate to login activity
        card_Logout.setOnClickListener(v -> logoutUser());

        // Set onClick for siren card: Navigate to profile activity (which may play the siren or show profile)
        cardSiren.setOnClickListener(view -> {
            Intent intent = new Intent(Activity_home.this, Activity_profile.class);
            startActivity(intent);
        });

        // Set onClick for self-defence card: Navigate to self-defence activity
        cardSelf.setOnClickListener(v -> {
            Intent intent = new Intent(Activity_home.this, Activity_selfdefence.class);
            startActivity(intent);
        });

        // Set onClick for "How to use" card: Navigate to the how-to-use activity
        howTo.setOnClickListener(v -> {
            Intent intent = new Intent(Activity_home.this, Activity_how.class);
            startActivity(intent);
        });
    }

    /**
     * Initialize the sensor manager, accelerometer, and sensor event listener for detecting shakes.
     */
    private void initializeSensors() {
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (accelerometer != null) {
                sensorEventListener = new SensorEventListener() {
                    @Override
                    public void onSensorChanged(SensorEvent event) {
                        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                            detectShake(event);
                        }
                    }
                    @Override
                    public void onAccuracyChanged(Sensor sensor, int accuracy) {
                        // Not used in this implementation
                    }
                };
                // Register the listener with UI delay
                sensorManager.registerListener(sensorEventListener, accelerometer, SensorManager.SENSOR_DELAY_UI);
            } else {
                Toast.makeText(this, "Accelerometer not available!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "SensorManager initialization failed!", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Setup listener for the toggle switch that stops emergency actions when switched off.
     */
    private void setupToggleListener() {
        toggleShake.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!isChecked) {
                Toast.makeText(this, "Emergency service Stopped", Toast.LENGTH_SHORT).show();
                stopEmergencyActions();
            }
        });
    }

    /**
     * Detects shake events based on accelerometer data.
     *
     * @param event The sensor event containing acceleration data.
     */
    private void detectShake(SensorEvent event) {
        // Get acceleration values along all three axes
        float x = event.values[0];
        float y = event.values[1];
        float z = event.values[2];

        // Calculate the magnitude of acceleration
        float accelerationMagnitude = (float) Math.sqrt(x * x + y * y + z * z);

        // Check if the magnitude exceeds the defined threshold
        if (accelerationMagnitude > SHAKE_THRESHOLD) {
            long currentTime = System.currentTimeMillis();
            // Start the timer if not already started
            if (shakeStartTime == 0) {
                shakeStartTime = currentTime;
            } else if (currentTime - shakeStartTime >= SHAKE_DURATION_THRESHOLD && !isEmergencyTriggered) {
                // If shake persists for the threshold duration, trigger emergency actions
                isEmergencyTriggered = true;
                triggerEmergencyActions("shake");
            }
        } else {
            // Reset shake timer and flag when acceleration drops below threshold
            shakeStartTime = 0;
            isEmergencyTriggered = false;
        }
    }

    /**
     * Trigger emergency actions such as vibrating, playing the siren, and sending location.
     */
    private void triggerEmergencyActions(String str) {
        if(str.equals("shake")) {
            // Vibrate the device for 2 seconds
            if (vibrator != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(2000, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(2000);
                }
            }

            // Play the siren sound and update toggle state
            if (mediaPlayer != null) {
                mediaPlayer.start();
                toggleShake.setChecked(true);
            }

            // Get current location and send an emergency SMS
            sendLocation();
        } else if (str.equals("help")) {
            sendLocation();
        }
    }

    /**
     * Retrieve the last known location and send it as an emergency message.
     */
    private void sendLocation() {
        // Check if location permission is granted
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Location permission not granted!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get the last known location
        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            // Build the location message with a Google Maps link
                            String locationMessage = "Hello, I am in danger, Please urgently reach me out. " +
                                    "Here is my live location:\n\n" +
                                    "Google Maps Link: https://www.google.com/maps?q=" + location.getLatitude() + "," + location.getLongitude();

                            sendMessage(locationMessage);
                        } else {
                            Toast.makeText(Activity_home.this, "Unable to get location!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    /**
     * Sends an SMS with the specified message to all emergency contacts (primary and relatives).
     *
     * @param message The emergency message to be sent.
     */
    private void sendMessage(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            boolean messageSent = false;
            
            // Send to primary emergency contact
            if (parentPhoneNumber != null && !parentPhoneNumber.isEmpty()) {
                smsManager.sendTextMessage(parentPhoneNumber, null, message, null, null);
                messageSent = true;
            }
            
            // Send to all relative contacts
            for (String phone : relativePhoneNumbers) {
                smsManager.sendTextMessage(phone, null, message, null, null);
                messageSent = true;
            }
            
            if (messageSent) {
                Toast.makeText(this, "Emergency messages sent to all contacts!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "No emergency contacts available", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send messages: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Checks and requests necessary permissions such as location and SMS.
     */
    private void checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.SEND_SMS
            }, PERMISSION_REQUEST_CODE);
        }
    }

    /**
     * Handles the permission request responses.
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (permissions.length > 0) {
                // Check for each permission and show corresponding Toast messages
                if (permissions[0].equals(Manifest.permission.ACCESS_FINE_LOCATION) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Location permission granted!", Toast.LENGTH_SHORT).show();
                } else if (permissions[0].equals(Manifest.permission.SEND_SMS) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "SMS permission granted!", Toast.LENGTH_SHORT).show();
                } else if (permissions[0].equals(Manifest.permission.CALL_PHONE) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Call permission granted!", Toast.LENGTH_SHORT).show();
                    emergencyCall(); // Make an emergency call immediately after permission is granted
                } else {
                    Toast.makeText(this, "Some permissions denied!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    /**
     * Handles cleanup by releasing sensor and media player resources.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Unregister sensor listener to prevent memory leaks
        if (sensorManager != null && sensorEventListener != null) {
            sensorManager.unregisterListener(sensorEventListener);
        }
        // Release media player resources
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
    }

    /**
     * Stops all emergency actions including vibration and siren sound.
     */
    private void stopEmergencyActions() {
        // Stop any ongoing vibration
        if (vibrator != null) {
            vibrator.cancel();
        }

        // Stop siren sound and reset media player
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.reset();
            mediaPlayer = MediaPlayer.create(this, R.raw.siren);
        }
    }

    /**
     * Clears user session and navigates back to the login activity.
     */
    private void logoutUser() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();

        Toast.makeText(Activity_home.this, "You have been logged out", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(Activity_home.this, Activity_login.class);
        startActivity(intent);
        finish();
    }

    /**
     * Initiates an emergency call to the parent's phone number.
     */
    private void emergencyCall() {
        // Check if CALL_PHONE permission is granted
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, PERMISSION_REQUEST_CODE);
            return;
        }
        // Start the call intent using the fetched parent's phone number
        if (parentPhoneNumber != null && !parentPhoneNumber.isEmpty()) {
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(android.net.Uri.parse("tel:" + parentPhoneNumber));
            startActivity(callIntent);
        } else {
            Toast.makeText(this, "Parent phone number not available", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handle key down event to start timing a potential long press of the volume down button.
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            // Start timing the press
            if (volumeDownPressTime == 0) {
                volumeDownPressTime = System.currentTimeMillis();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    /**
     * Handle key up event to detect if volume down was long pressed and trigger emergency call.
     */
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            long pressDuration = System.currentTimeMillis() - volumeDownPressTime;
            volumeDownPressTime = 0; // Reset timer

            if (pressDuration >= LONG_PRESS_THRESHOLD) {
                // Long press detected: Trigger emergency call
                emergencyCall();
            } else {
                Toast.makeText(this, "Long press Volume Down to trigger emergency call", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void initializeVoiceRecognition() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");

        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {}

            @Override
            public void onBeginningOfSpeech() {}

            @Override
            public void onRmsChanged(float rmsdB) {}

            @Override
            public void onBufferReceived(byte[] buffer) {}

            @Override
            public void onEndOfSpeech() {
                startListening(); // Restart listening after speech ends
            }

            @Override
            public void onError(int error) {
                startListening(); // Restart listening on any error
            }

            @Override
            public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null) {
                    for (String result : matches) {
                        if (result.toLowerCase().contains("help")) { // Check if "help" is anywhere in the sentence
                            triggerEmergencyActions("help");
                            emergencyCall(); // Trigger emergency call
                            return;
                        }
                    }
                }
                startListening(); // Restart listening if "help" is not detected
            }

            @Override
            public void onPartialResults(Bundle partialResults) {}

            @Override
            public void onEvent(int eventType, Bundle params) {}
        });

        startListening(); // Start listening initially
    }

    private void startListening() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        speechRecognizer.startListening(intent);
    }
}
