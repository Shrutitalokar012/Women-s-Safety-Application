package com.example.women_safety;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;

import java.util.List;

public class OnboardingAdapter extends RecyclerView.Adapter<OnboardingAdapter.OnboardingViewHolder> {

    private final List<OnboardingItem> onboardingItems;

    public OnboardingAdapter(List<OnboardingItem> onboardingItems) {
        this.onboardingItems = onboardingItems;
    }

    @NonNull
    @Override
    public OnboardingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.slide_item, parent, false);
        return new OnboardingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OnboardingViewHolder holder, int position) {
        holder.bind(onboardingItems.get(position));
    }

    @Override
    public int getItemCount() {
        return onboardingItems.size();
    }

    static class OnboardingViewHolder extends RecyclerView.ViewHolder {
        private final LottieAnimationView animationView;
        private final TextView titleText;
        private final TextView descriptionText;

        public OnboardingViewHolder(@NonNull View itemView) {
            super(itemView);
            animationView = itemView.findViewById(R.id.onboarding_image);
            titleText = itemView.findViewById(R.id.onboarding_title);
            descriptionText = itemView.findViewById(R.id.onboarding_desc);
        }

        void bind(OnboardingItem item) {
            animationView.setAnimation(item.getAnimationRes()); // Load animation
            animationView.playAnimation(); // Start animation
            titleText.setText(item.getTitle());
            descriptionText.setText(item.getDescription());
        }
    }
}
