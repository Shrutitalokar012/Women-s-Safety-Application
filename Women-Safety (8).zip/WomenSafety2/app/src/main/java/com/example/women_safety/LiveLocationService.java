package com.example.women_safety;

public class LiveLocationService {
}
