package com.example.women_safety;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Activity_forgot_password extends AppCompatActivity {

    private TextInputEditText emailInput;
    private Button sendOtpButton;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        // Initialize UI elements
        emailInput = findViewById(R.id.emailInput);
        sendOtpButton = findViewById(R.id.sendOtpButton);

        //back button
        ImageButton back = findViewById(R.id.back_button);
        back.setOnClickListener(v -> finish());


        // Initialize Firebase reference (assuming user records are under "Users")
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");

        // Set listener for "Send OTP" button
        sendOtpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String email = emailInput.getText().toString().trim();
                if (email.isEmpty()) {
                    Toast.makeText(Activity_forgot_password.this, "Please enter your email", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Query the database to check if the user exists
                Query query = databaseReference.orderByChild("email").equalTo(email);
                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            // User exists, redirect to New_Password activity and pass the email
                            Intent intent = new Intent(Activity_forgot_password.this, Activity_new_password.class);
                            intent.putExtra("email", email);
                            startActivity(intent);
                        } else {
                            // No user found – show pop-up message
                            Toast.makeText(Activity_forgot_password.this, "No user found for this email please try again later", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(Activity_forgot_password.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
