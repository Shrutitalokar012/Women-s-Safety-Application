package com.example.women_safety;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.Map;

public class Activity_update_relative extends AppCompatActivity {

    private TextInputEditText inputName, inputPhone, inputRelationship;
    private Button btnSave;
    private DatabaseReference relativeRef;
    private SharedPreferences sharedPreferences;
    private String relativeId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_relative);

        // Initialize UI components
        inputName = findViewById(R.id.input_name);
        inputPhone = findViewById(R.id.input_phone);
        inputRelationship = findViewById(R.id.input_relationship);
        btnSave = findViewById(R.id.btn_save);

        // Setup back button
        ImageButton backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(v -> finish());

        // Retrieve relative info from the intent extras
        relativeId = getIntent().getStringExtra("relativeId");
        String name = getIntent().getStringExtra("name");
        String phone = getIntent().getStringExtra("phone");
        String relationship = getIntent().getStringExtra("relationship");

        // Pre-fill the fields with the current data
        inputName.setText(name);
        inputPhone.setText(phone);
        inputRelationship.setText(relationship);

        // Retrieve user's uid from SharedPreferences
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String userId = sharedPreferences.getString("uid", "");
        if (userId.isEmpty()) {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Initialize Firebase reference to this relative
        relativeRef = FirebaseDatabase.getInstance().getReference("Users")
                .child(userId).child("relatives").child(relativeId);

        // Save (update) button click listener
        btnSave.setOnClickListener(v -> updateRelative());
    }

    private void updateRelative() {
        String newName = inputName.getText().toString().trim();
        String newPhone = inputPhone.getText().toString().trim();
        String newRelationship = inputRelationship.getText().toString().trim();

        // Validate input fields
        if (TextUtils.isEmpty(newName)) {
            inputName.setError("Enter full name");
            return;
        }
        if (TextUtils.isEmpty(newPhone)) {
            inputPhone.setError("Enter phone number");
            return;
        }
        if (TextUtils.isEmpty(newRelationship)) {
            inputRelationship.setError("Enter relationship");
            return;
        }

        // Prepare the updated data
        Map<String, String> updatedData = new HashMap<>();
        updatedData.put("relativeId", relativeId);
        updatedData.put("name", newName);
        updatedData.put("phone", newPhone);
        updatedData.put("relationship", newRelationship);

        // Update the relative node in Firebase
        relativeRef.setValue(updatedData, (DatabaseError error, @NonNull DatabaseReference ref) -> {
            if (error == null) {
                Toast.makeText(Activity_update_relative.this, "Relative updated successfully", Toast.LENGTH_SHORT).show();
                finish(); // Close activity after successful update
            } else {
                Toast.makeText(Activity_update_relative.this, "Update failed: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
