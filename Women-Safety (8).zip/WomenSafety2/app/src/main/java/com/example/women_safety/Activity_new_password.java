package com.example.women_safety;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Activity_new_password extends AppCompatActivity {

    private TextInputEditText otpInput, passwordInput, c_passwordInput;
    private Button changePasswordButton;
    TextView resendOtpButton;
    private String generatedOtp;
    private String email;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_password);  // Ensure your layout file name matches

        // Get the email from the intent
        email = getIntent().getStringExtra("email");

        // Initialize UI elements
        otpInput = findViewById(R.id.otpInput);
        passwordInput = findViewById(R.id.passwordInput);
        c_passwordInput = findViewById(R.id.c_passwordInput);
        changePasswordButton = findViewById(R.id.sendOtpButton); // Button labeled "Change Password" per XML
        resendOtpButton = findViewById(R.id.resendOTP);      // New button for resending OTP

        //back button
        ImageButton back = findViewById(R.id.back_button);
        back.setOnClickListener(v -> finish());

        // Initialize Firebase reference (assuming user records are under "Users")
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");

        // Generate a 6-digit OTP and send it to the user's email
        generatedOtp = String.valueOf(new Random().nextInt(900000) + 100000);
        sendOtpEmail(email, generatedOtp);

        // Set click listener for the "Change Password" button
        changePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String enteredOtp = otpInput.getText().toString().trim();
                String newPassword = passwordInput.getText().toString().trim();
                String confirmPassword = c_passwordInput.getText().toString().trim();

                if (enteredOtp.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                    Toast.makeText(Activity_new_password.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!enteredOtp.equals(generatedOtp)) {
                    Toast.makeText(Activity_new_password.this, "Invalid OTP. Please try again.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!newPassword.equals(confirmPassword)) {
                    Toast.makeText(Activity_new_password.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Query the database to find the user by email and update the password
                Query query = databaseReference.orderByChild("email").equalTo(email);
                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            // For each matching user, update the password
                            for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                                userSnapshot.getRef().child("password").setValue(newPassword);
                            }
                            Toast.makeText(Activity_new_password.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Activity_new_password.this, Activity_changed.class);
                            startActivity(intent);
                            // Optionally, navigate to the login screen or another activity here
                        } else {
                            Toast.makeText(Activity_new_password.this, "User record not found", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(Activity_new_password.this, "Database error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        // Set click listener for the "Resend OTP" button
        resendOtpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Generate a new OTP
                generatedOtp = String.valueOf(new Random().nextInt(900000) + 100000);
                // Send the new OTP to the user's email
                sendOtpEmail(email, generatedOtp);
            }
        });
    }

    /**
     * Sends an OTP email to the given recipient using JavaMail in a background thread.
     *
     * @param recipientEmail The email address to send the OTP.
     * @param otp            The OTP to send.
     */
    private void sendOtpEmail(final String recipientEmail, final String otp) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String senderEmail = "womensafety06@gmail.com"; // Replace with your sender email
                    final String senderPassword = "hbkj rkcx kjae rlmi";      // Replace with your app-specific password

                    Properties props = new Properties();
                    props.put("mail.smtp.auth", "true");
                    props.put("mail.smtp.starttls.enable", "true");
                    props.put("mail.smtp.host", "smtp.gmail.com");
                    props.put("mail.smtp.port", "587");

                    Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(senderEmail, senderPassword);
                        }
                    });

                    Message message = new MimeMessage(session);
                    message.setFrom(new InternetAddress(senderEmail));
                    message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
                    message.setSubject("Your OTP Code");
                    message.setText("Your OTP is: " + otp);

                    Transport.send(message);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Toast message after successful OTP send
                            Toast.makeText(Activity_new_password.this, "OTP sent successfully", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (final Exception e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(Activity_new_password.this, "Failed to send OTP: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }
}
