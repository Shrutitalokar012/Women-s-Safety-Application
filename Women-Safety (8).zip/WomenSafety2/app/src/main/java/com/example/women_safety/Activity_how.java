package com.example.women_safety;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.tbuonomo.viewpagerdotsindicator.WormDotsIndicator;

import java.util.ArrayList;
import java.util.List;

public class Activity_how extends AppCompatActivity {

    private ViewPager2 onboardingViewPager;
    private Button nextButton;
    private TextView skipButton;
    private ImageButton back_Button;
    private OnboardingAdapter onboardingAdapter;
    private int currentPosition = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_how);

        onboardingViewPager = findViewById(R.id.onboardingViewPager);
        nextButton = findViewById(R.id.next_button);
        skipButton = findViewById(R.id.skip_button);
        back_Button = findViewById(R.id.back_button);


        setupOnboardingItems();

        // Dots Indicator
        WormDotsIndicator dotsIndicator = findViewById(R.id.indicator_layout);
        dotsIndicator.attachTo(onboardingViewPager);

        onboardingViewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                currentPosition = position;
                if (position == onboardingAdapter.getItemCount() - 1) {
                    nextButton.setText("Get Started");
                } else {
                    nextButton.setText("Next");
                }
            }
        });

        nextButton.setOnClickListener(v -> {
            if (currentPosition < onboardingAdapter.getItemCount() - 1) {
                onboardingViewPager.setCurrentItem(currentPosition + 1);
            } else {
                startMainActivity();
            }
        });

        skipButton.setOnClickListener(v -> startMainActivity());
        back_Button.setOnClickListener(v -> finish());
    }

    private void setupOnboardingItems() {
        List<OnboardingItem> onboardingItems = new ArrayList<>();
        onboardingItems.add(new OnboardingItem(R.raw.welcome1, "Welcome to Be Safe",
                "Thank you for choosing our Women Safety app. Your safety is our priority. Click 'Next' to learn how to use this app and stay safe at all times."));

        onboardingItems.add(new OnboardingItem(R.raw.welcome, "Shake to Trigger Emergency",
                "Simply shake your phone to activate the emergency mode. A loud siren will sound, and your live location will be instantly sent to your registered emergency contacts."));

        onboardingItems.add(new OnboardingItem(R.raw.shake, "Emergency Call with Volume Down",
                "Long press the volume down button to instantly call your registered emergency contact. Stay prepared for any situation with a quick and discreet way to reach help."));
        onboardingItems.add(new OnboardingItem(R.raw.we, "Let's Get Started!", "Begin your journey"));

        onboardingAdapter = new OnboardingAdapter(onboardingItems);
        onboardingViewPager.setAdapter(onboardingAdapter);
    }

    private void startMainActivity() {
        startActivity(new Intent(this, Activity_home.class));
        finish();
    }
}
