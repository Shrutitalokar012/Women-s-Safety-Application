package com.example.women_safety;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Activity_register extends AppCompatActivity {

    // UI elements
    private TextInputEditText fullNameInput, phoneInput, emergencyContactInput, emailInput, passwordInput;
    private Button registerButton;

    // Firebase database reference
    private DatabaseReference databaseReference;

    // Variables to temporarily store registration details
    private String registeredFullName, registeredPhone, registeredEmergencyContact, registeredEmail, registeredPassword;
    // Generated OTP to be sent to the user's email
    private String generatedOtp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Initialize Firebase Database
        databaseReference = FirebaseDatabase.getInstance().getReference("Users");

        // Initialize UI Elements
        fullNameInput = findViewById(R.id.fullNameInput);
        phoneInput = findViewById(R.id.phoneInput);
        emergencyContactInput = findViewById(R.id.emergencyContactInput);
        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        registerButton = findViewById(R.id.registerButton);

        // Set onClick for Login Text to navigate to the login screen
        findViewById(R.id.loginText).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Activity_register.this, Activity_login.class);
                startActivity(intent);
            }
        });

        // When the user taps the Register button:
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Read input field values
                final String fullName = fullNameInput.getText().toString().trim();
                final String phone = phoneInput.getText().toString().trim();
                final String emergencyContact = emergencyContactInput.getText().toString().trim();
                final String email = emailInput.getText().toString().trim();
                final String password = passwordInput.getText().toString().trim();

                // Validate that no field is empty
                if (TextUtils.isEmpty(fullName) || TextUtils.isEmpty(phone) ||
                        TextUtils.isEmpty(emergencyContact) || TextUtils.isEmpty(email) ||
                        TextUtils.isEmpty(password)) {
                    Toast.makeText(Activity_register.this, "Please fill in all fields!", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if a user with this email already exists in the database
                databaseReference.orderByChild("email").equalTo(email)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    // Email already exists - prompt the user to login
                                    Toast.makeText(Activity_register.this, "User already registered. Please login.", Toast.LENGTH_SHORT).show();
                                } else {
                                    // Email not found: save registration details
                                    registeredFullName = fullName;
                                    registeredPhone = phone;
                                    registeredEmergencyContact = emergencyContact;
                                    registeredEmail = email;
                                    registeredPassword = password;

                                    // Generate a 6-digit OTP
                                    generatedOtp = String.valueOf(100000 + new Random().nextInt(900000));

                                    // Send the OTP via email using the updated sendOtpEmail method
                                    sendOtpEmail(registeredEmail, generatedOtp);

                                    // Inform the user that the OTP has been sent
                                    Toast.makeText(Activity_register.this, "OTP sent to your email. Please check your inbox.", Toast.LENGTH_LONG).show();

                                    // Redirect to the Verify OTP Activity, passing along all registration details and the generated OTP
                                    Intent intent = new Intent(Activity_register.this, Activty_verify_email.class);
                                    intent.putExtra("fullName", registeredFullName);
                                    intent.putExtra("phone", registeredPhone);
                                    intent.putExtra("emergencyContact", registeredEmergencyContact);
                                    intent.putExtra("email", registeredEmail);
                                    intent.putExtra("password", registeredPassword);
                                    intent.putExtra("generatedOtp", generatedOtp);
                                    startActivity(intent);
                                    finish();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                Toast.makeText(Activity_register.this, "Database error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }

    /**
     * Sends an OTP email to the given recipient using JavaMail in a background thread.
     *
     * @param recipientEmail The email address to send the OTP.
     * @param otp            The OTP to send.
     */
    private void sendOtpEmail(final String recipientEmail, final String otp) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String senderEmail = "womensafety06@gmail.com"; // Replace with your sender email
                    final String senderPassword = "hbkj rkcx kjae rlmi";      // Replace with your app-specific password

                    Properties props = new Properties();
                    props.put("mail.smtp.auth", "true");
                    props.put("mail.smtp.starttls.enable", "true");
                    props.put("mail.smtp.host", "smtp.gmail.com");
                    props.put("mail.smtp.port", "587");

                    Session session = Session.getInstance(props, new javax.mail.Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(senderEmail, senderPassword);
                        }
                    });

                    Message message = new MimeMessage(session);
                    message.setFrom(new InternetAddress(senderEmail));
                    message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
                    message.setSubject("Your OTP Code");
                    message.setText("Your OTP is: " + otp);

                    Transport.send(message);

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            // Toast message after successful OTP send
                            Toast.makeText(Activity_register.this, "OTP sent successfully", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (final Exception e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(Activity_register.this, "Failed to send OTP: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }
}
